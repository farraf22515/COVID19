import React, { Component } from "react";
import { GoogleMap, withGoogleMap, withScriptjs, Marker } from "react-google-maps";



class Map extends Component {
  
  constructor(){
    super()
    this.state = {
      markers: []
    };
    console.log(navigator.geolocation.getCurrentPosition(this.position))
  }
  handleClick = event => {
    this.props.handleChange(event.latLng)
    console.log(this.state);
    const markers = this.state.markers;
    const marker = {
      position: event.latLng,
      defaulltAnimation: 1,
      key: "select"
    };
    markers.pop();
    markers.push(marker)
    this.setState({ markers: markers });
  };
  position = (pos) =>{
    const markers = this.state.markers;
    const marker = {
      position : {
        lat : pos.coords.latitude,
        lng: pos.coords.longitude
      },
      defaulltAnimation:1,
      key:"select"
    }
    markers.push(marker)
    this.setState({markers: markers})
    this.props.handleCurrentPosition(pos.coords.latitude,pos.coords.longitude)
  }
  render() {
    return (
      <GoogleMap
        defaultZoom={10}
        defaultCenter={{ lat: 13.745541, lng: 100.533135 }}
        onClick={event => {
          this.handleClick(event);
        }}
      >
        {this.state.markers.map(doc => (
          <Marker {...doc} />
        ))}
      </GoogleMap>
    );
  }
}

const WrappedMap = withScriptjs(withGoogleMap(Map));

class Maps extends Component {
  state={}
  handleChange = (latLng) => {
    console.log(latLng.lat());
    console.log(latLng.lng());
    this.setState({lat : latLng.lat().toFixed(4), lng:latLng.lng().toFixed(4)})
    this.props.handleChangeLocation(latLng)
  }

  handleCurrentPosition = (lat,lng)=>{
    this.setState({lat : lat,lng : lng})
  }
  render() {
    return (
      <div className="App">

        {console.log(process.env.KEY)}
        <div style={{ width: "100%", height: "80vh" }}>
          <WrappedMap
            googleMapURL={`https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=geometry,drawing,places&key=AIzaSyAEMhMOkW6z6JvsdOSxAcbGlLFujGLQhFQ`}
            loadingElement={<div style={{ height: `100%` }} />}
            containerElement={<div style={{ height: `100%` }} />}
            mapElement={<div style={{ height: `100%` }} />}
            handleChange={this.handleChange}
            handleCurrentPosition = {this.handleCurrentPosition}
          />
        </div>
        <h4>latitude : {this.state.lat} , longitude : {this.state.lng}</h4>
      </div >
    );
  }
}
export default Maps